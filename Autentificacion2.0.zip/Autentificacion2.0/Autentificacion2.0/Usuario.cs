﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autentificacion2._0
{
    class Usuario
    {
        //Se crean los atributos que tendra el usuario para registrase o iniciar sesión
        public string Nombre { get; set; }
        public string Password { get; set; }
        public string Username { get; set; }
    }
}
