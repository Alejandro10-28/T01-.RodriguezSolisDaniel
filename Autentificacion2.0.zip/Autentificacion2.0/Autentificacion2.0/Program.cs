﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autentificacion2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            //Se instancia principal que es donde tengo la bienvenida y menu con el que interactua el usuario.
            Principal M = new Principal();
            M.Welcome();


           
        }
    }
}
